let allVideos = [
   {
      name: "Video 1",
      src: "/com/Vid/1",
      id: "vid_1"
   },
   {
      name: "video 2",
      src: "/com/Vid/2",
      id: "vid_2"
   },
   {
      name: "video 3",
      src: "/com/Vid/3",
      id: "vid_3"
   },
   {
      name: "video 4",
      src: "/com/Vid/4",
      id: "vid_4"
   },
   {
      name: "video 5",
      src: "/com/Vid/5",
      id: "vid_5"
   },
   {
      name: "video 6",
      src: "/com/Vid/6",
      id: "vid_6"
   },
   {
      name: "video 7",
      src: "/com/Vid/8",
      id: "vid_8"
   },
   {
      name: "video 8",
      src: "/com/Vid/9",
      id: "vid_9"
   },
   {
      name: "video 9",
      src: "/com/Vid/10",
      id: "vid_10"
   },
   {
      name: "video 10",
      src: "/com/Vid/11",
      id: "vid_11"
   },
   {
      name: "video 11",
      src: "/com/Vid/12",
      id: "vid_12"
   },
   {
      name: "video 12",
      src: "/com/Vid/13",
      id: "vid_13"
   },
   {
      name: "video 13",
      src: "/com/Vid/14",
      id: "vid_14"
   }
]